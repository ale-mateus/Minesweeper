#include "Minesweeper.h"

// starts the minesweeper
int main() {launch();}