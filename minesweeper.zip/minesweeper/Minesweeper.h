#ifndef PROJECT4V2_MINESWEEPER_H
#define PROJECT4V2_MINESWEEPER_H

// Function prototypes
int launch();
void restart();
void render();
void toggleDebugMode();
bool getDebugMode();


#endif //PROJECT4V2_MINESWEEPER_H
